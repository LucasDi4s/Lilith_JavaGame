package main;

public class Inicio {

    public static void main(String[] args) {
        new Gameclass();
    }


}
