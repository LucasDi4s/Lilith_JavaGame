package levels;

import java.awt.image.BufferedImage;
import main.Gameclass;

public class levelManager {

    private Gameclass game;
    private BufferedImage LevelSprites;
    private final Gameclass gameclass;

    public levelManager(Gameclass gameclass) {
        this.gameclass = gameclass;
        
    }
}
